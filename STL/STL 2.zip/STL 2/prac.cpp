#include<vector>
#include<iostream>
#include<list>
#include<deque>
#include<queue>
#include<stack>
#include<bits/stdc++.h>
using namespace std;

int main(){
    // vector<int> v;
    // v.push_back(1);
    // v.emplace_back(2);

    // v.erase(v.begin());
    // v.pop_back();

    // v.clear();
    // v.emplace_back(1);
    // cout<<v.size()<<endl;;
    // v.insert(v.begin(),5,10);
    // for(auto &it:v){
    //     cout<<it<<" ";
    // }
    // cout<<endl;



    // list<int> l;
    // l.push_back(1);
    // l.push_front(2);
    // l.pop_back();
    // l.pop_front();


    // deque<int> dq;

    // stack<int> s;
    // s.push(1);
    // s.push(2);
    // s.pop();
    // cout<<s.top()<<endl;

    // queue<int> q;
    // q.push(1);
    // q.pop();
    // q.front();
    // q.back();

    priority_queue<int> pq;
    priority_queue<int,vector<int>,greater<int>> pq1;
}