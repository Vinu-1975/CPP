#include<bits/stdc++.h>
using namespace std;

int main(){
    map<int,string> m;
    m[1]="abc";
    m.insert({2,"def"});

    
}